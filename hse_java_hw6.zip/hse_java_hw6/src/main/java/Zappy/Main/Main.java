package Zappy.Main;

import Zappy.io.FileIterator;

public class Main {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
