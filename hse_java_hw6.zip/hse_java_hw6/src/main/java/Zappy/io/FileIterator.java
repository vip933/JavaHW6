package Zappy.io;

import java.io.*;
import java.util.Iterator;

public class FileIterator implements Iterator<String>, AutoCloseable {

    private final BufferedReader bufferedReader;
    private String currentLine;

    public FileIterator(String pathToFile) {
        try {
            this.bufferedReader = new BufferedReader(new FileReader(pathToFile));
            currentLine = this.bufferedReader.readLine();
        } catch (IOException ex) {
            throw new UncheckedIOException(ex);
        }
    }

    @Override
    public void close() throws IOException {
        bufferedReader.close();
        System.out.println("Successfully closed file!");
    }

    @Override
    public boolean hasNext() {
        try {
            currentLine = bufferedReader.readLine();
            return currentLine != null;
        } catch (IOException ex) {
            return false;
        }
    }

    @Override
    public String next() {
        return currentLine;
    }
}
