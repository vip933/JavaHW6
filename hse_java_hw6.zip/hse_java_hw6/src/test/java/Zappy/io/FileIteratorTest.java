package Zappy.io;

import org.junit.jupiter.api.Test;

import java.io.UncheckedIOException;

import static org.junit.jupiter.api.Assertions.*;

public class FileIteratorTest {

    @Test
    void iteratorHasNextShouldReturnFalseOnEmptyFIle() {
        String path = FileIteratorTest.class.getResource("/empty_file.txt").getPath();
        assertFalse(new FileIterator(path).hasNext());
    }

    @Test
    void iteratorHasNextShouldReturnFalseOnEmptyLine() {
        String path = FileIteratorTest.class.getResource("/one_line.txt").getPath();
        FileIterator fileIterator = new FileIterator(path);
        fileIterator.hasNext();
        assertFalse(fileIterator.hasNext());
    }

    @Test
    void iteratorHasNextShouldReturnTrueIfFileContainsLine() {
        String path = FileIteratorTest.class.getResource("/one_line.txt").getPath();
        assertTrue(new FileIterator(path).hasNext());
    }

    @Test
    void iteratorConstructorShouldThrowErrorIfFileDoesntExist() {
        assertThrows(UncheckedIOException.class, () -> new FileIterator("/abra-cadabra.wtf"));
    }

    @Test
    void iteratorNextShouldReturnNextLine() {
        String path = FileIteratorTest.class.getResource("/one_line.txt").getPath();
        assertEquals(new FileIterator(path).next(), "first_line");
    }

    @Test
    void iteratorShouldBeClosedAfterEnd() {
        String path = FileIteratorTest.class.getResource("/one_line.txt").getPath();
        assertDoesNotThrow(() -> new FileIterator(path));
    }
}
